package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private recyleradapter adapter;
    private RecyclerView recyler;
    private ArrayList<String>name=new ArrayList<>();
    private ArrayList<String>number=new ArrayList<>();
    private ArrayList<Integer>image=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyler=findViewById(R.id.recycler);
        recyler.setLayoutManager(new LinearLayoutManager(MainActivity.this));

        name.add("Papa");
        name.add("Bhaiya");
        name.add("Karunesh ");
        name.add("Bhau");
        name.add("Uttam");
        name.add("Arastu");
        name.add("Manu");
        name.add("Govind");
        name.add("Mukund");


        number.add("5788475879");
        number.add("3789898989");
        number.add("7905686885");
        number.add("9451473874");
        number.add("6347387938");
        number.add("8192392039");
        number.add("9459832980");
        number.add("4549034095");
        number.add("8988934095");

       image.add(R.drawable.aa);
       image.add(R.drawable.b);
        image.add(R.drawable.c);
        image.add(R.drawable.d);
        image.add(R.drawable.e);
        image.add(R.drawable.f);
        image.add(R.drawable.g);
        image.add(R.drawable.h);
        image.add(R.drawable.i);


        adapter=new recyleradapter(name,number,image,MainActivity.this);
        recyler.setAdapter(adapter);


    }
}