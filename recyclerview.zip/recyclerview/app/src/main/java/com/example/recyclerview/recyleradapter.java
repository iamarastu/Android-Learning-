package com.example.recyclerview;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class recyleradapter extends RecyclerView.Adapter<recyleradapter.holder> {
    private ArrayList<String> name;
    private ArrayList<String>number;
    private ArrayList<Integer>image;
    private Context context;

    public recyleradapter(ArrayList<String> name, ArrayList<String> number, ArrayList<Integer> image, Context context) {
        this.name = name;
        this.number = number;
        this.image = image;
        this.context = context;


    }

    @NonNull
    @Override
    public holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //in this method we'll design card view, which design will dissplayed on recyler view

        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.card,parent,false);

        return new holder(view);


    }

    @Override
    public void onBindViewHolder(@NonNull holder holder, @SuppressLint("RecyclerView") int position) {
        //this method will show the data on the screen

        holder.textview.setText(name.get(position));
        holder.textview2.setText(number.get(position));
        holder.image.setImageResource(image.get(position));

        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(position==0)
                {
                    Toast.makeText(context, "You selected papa", Toast.LENGTH_SHORT).show();
                }
                else if(position==1)
                {
                    Toast.makeText(context, "You selected dugu bhaiya", Toast.LENGTH_SHORT).show();
                }
                else if(position==1)
                {
                    Toast.makeText(context, "You selected Karunesh bhaiya", Toast.LENGTH_SHORT).show();
                }
                else if(position==1)
                {
                    Toast.makeText(context, "You selected bhau", Toast.LENGTH_SHORT).show();
                }
                else if(position==1)
                {
                    Toast.makeText(context, "You selected Uttam", Toast.LENGTH_SHORT).show();
                }
                else if(position==1)
                {
                    Toast.makeText(context, "You selected Arastu", Toast.LENGTH_SHORT).show();
                }
                else if(position==1)
                {
                    Toast.makeText(context, "You selected Manu", Toast.LENGTH_SHORT).show();
                }
                else if(position==1)
                {
                    Toast.makeText(context, "You selected Govind", Toast.LENGTH_SHORT).show();
                }
                else if(position==1)
                {
                    Toast.makeText(context, "You selected Mukund", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        //this method will specify the amount of data to be displayed

        return name.size();

    }

    public class holder extends RecyclerView.ViewHolder {
        private TextView textview,textview2;
        private ImageView image;
        private CardView card;
        public holder(@NonNull View itemView) {
            super(itemView);

            card=itemView.findViewById(R.id.card);
            textview=itemView.findViewById(R.id.textview);
            textview2=itemView.findViewById(R.id.textview2);
            image=itemView.findViewById(R.id.image);
        }
    }
}

