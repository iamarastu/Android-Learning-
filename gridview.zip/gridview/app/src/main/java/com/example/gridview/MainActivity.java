package com.example.gridview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    GridView grid;
    ArrayList<String> text=new ArrayList<>();
    ArrayList<Integer> image=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        grid=findViewById(R.id.grid);
        fillarray();

        gridadapter adapter=new gridadapter(this,text,image);
        grid.setAdapter(adapter);

        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), "You selected singer "+text.get(position), Toast.LENGTH_LONG).show();
            }
        });
    }
    public void fillarray()
    {
        text.add("Shawn Mendes");
        text.add("Taylor Swift");
        text.add("Billie Eliesh");
        text.add("Charlie Puth");
        text.add("Saliena Gomez");
        text.add("Anne Marie");
        text.add("Katty Perry");
        text.add("Halsey");
        text.add("Justin Biber");

        image.add(R.drawable.shawn);
        image.add(R.drawable.taylor);
        image.add(R.drawable.billie);
        image.add(R.drawable.charlie);
        image.add(R.drawable.saliena);
        image.add(R.drawable.anne);
        image.add(R.drawable.ketty);
        image.add(R.drawable.halsey);
        image.add(R.drawable.justin);
    }
}