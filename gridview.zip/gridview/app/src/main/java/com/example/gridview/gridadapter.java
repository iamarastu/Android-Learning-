package com.example.gridview;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class gridadapter extends BaseAdapter {
    Context context;
    ArrayList<String> text=new ArrayList<>();
    ArrayList<Integer> image=new ArrayList<>();

    public gridadapter(Context context, ArrayList<String> text, ArrayList<Integer> image) {
        this.context = context;
        this.text = text;
        this.image = image;
    }

    @Override
    public int getCount() {
        return text.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertview, ViewGroup parent) {

        @SuppressLint("ViewHolder") View view=LayoutInflater.from(parent.getContext()).inflate(R.layout.gridview,parent,false);

        ImageView imageView=view.findViewById(R.id.img);
        TextView textView=view.findViewById(R.id.textview);

       imageView.setImageResource(image.get(position));
       textView.setText(text.get(position));
        return view;
    }
}
